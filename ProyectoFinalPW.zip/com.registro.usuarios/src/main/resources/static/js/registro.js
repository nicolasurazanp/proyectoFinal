document.getElementById('singaUp').addEventListener('click', function () {
    // Obtener los valores de los campos
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    // Validar el correo electrónico
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      alert('Por favor, ingrese un correo electrónico válido.');
      return;
    }
  
    // Validar la contraseña (mínimo 6 caracteres, una letra, un número y un carácter especial)
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@#$%^&+=!])[A-Za-z\d@#$%^&+=!]{6,}$/;
    if (!passwordRegex.test(password)) {
      alert('La contraseña debe tener al menos 6 caracteres, una letra, un número y un carácter especial.');
      return;
    }
  
    // Si pasa todas las validaciones, puedes enviar el formulario o realizar otras acciones
    alert('Registro exitoso');
  });
  
 